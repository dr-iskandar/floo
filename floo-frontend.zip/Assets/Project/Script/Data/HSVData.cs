﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class HSVData
{
	public string colorHSVCodeId;
//	public string colorHSVCodeName;
	public string fishSkin;
}

﻿using UnityEngine;
using System.Collections;

public class GameData 
{
	public static string appVersion = "1.1.6";
	public static string assetVersion = "1.0";

}
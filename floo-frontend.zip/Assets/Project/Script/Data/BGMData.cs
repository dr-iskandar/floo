﻿using UnityEngine;
using System.Collections;

public enum BGMData
{
	Ingame = 1,
	MainMenu = 2,
	PredatorArea = 3,
	PredatorChase = 4,
	PredatorAreaShark = 5,
	MainMenuChristmas = 6
}

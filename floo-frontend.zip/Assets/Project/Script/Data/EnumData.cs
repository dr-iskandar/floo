﻿using UnityEngine;
using System.Collections;

public class EnumData 
{
	public enum PopupState 
	{
		off = 0,
		on = 1
	}

	public enum PanelState 
	{
		off = 0,
		on = 1
	}

	public enum SuddenPopupState 
	{
		off = 0,
		on = 1
	}
}

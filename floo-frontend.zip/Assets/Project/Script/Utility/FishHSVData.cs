﻿using UnityEngine;
using System.Collections;

public class FishHSVData {

	public float fishHue;
	public float fishSaturation;
	public float fishValue;
	public float fishEyeHue;
	public float fishEyeSaturation;
	public float fishEyeValue;

}

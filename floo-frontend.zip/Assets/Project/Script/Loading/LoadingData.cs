﻿using UnityEngine;
using System.Collections;

public class LoadingData : MonoBehaviour {

	public static string playerId;
	public static string email;
	public static string version = "1.4";
	public static string currentAssetVersion;
}

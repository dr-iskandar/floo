﻿///Credit judah4
///Sourced from - http://forum.unity3d.com/threads/color-picker.267043/

using UnityEngine.Events;
namespace UnityEngine.UI.Extensions
{
    public class HSVSliderEvent : UnityEvent<Color>
    {

    }
}

﻿/*****************************************************************************
 * SkeletonRagdoll2D added by Mitch Thompson
 * Full irrevocable rights and permissions granted to Esoteric Software
*****************************************************************************/

using UnityEngine;
using UnityEditor;

namespace Spine.Unity.Modules {
	public class SkeletonRagdoll2DInspector {}
}
